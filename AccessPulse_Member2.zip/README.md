# AccessPulse – Member 2: Emergency Evacuation & Volunteer Help

## Files
- `common/AccessPulseData.h`: shared structures copied from the agreed project contract.
- `member2_emergency_help/Emergency.h`: public interface and result structures.
- `member2_emergency_help/Emergency.cpp`: implementation.
- `member2_emergency_help/test_emergency.cpp`: demonstration/test program.
- `data/`: saved volunteer and request records.

## Compile and run
Open a terminal in the `AccessPulse_Member2` folder:

```bash
g++ -std=c++11 member2_emergency_help/Emergency.cpp member2_emergency_help/test_emergency.cpp -o member2_demo
./member2_demo
```

Run the command from the project root; the demo saves records in `data/volunteers.txt` and `data/requests.txt`.

## Public functions
- `findEvacuationRoute(startLocationId)`
- `registerVolunteer(volunteer)`
- `setVolunteerAvailability(volunteerId, available)`
- `createHelpRequest(request)`
- `assignVolunteer(requestId)` – automatically chooses the nearest reachable, available volunteer with the matching help skill (or `ANY`).
- `updateRequestStatus(requestId, status)`
- `displayVolunteers()`, `displayRequests()`, `displayPendingQueue()`
- `saveVolunteers(filename)`, `saveRequests(filename)`
- `loadVolunteers(filename)`, `loadRequests(filename)`

## Important integration notes
1. The `EmergencyHelpSystem` receives the building's `Location[]` and `Connection[]` arrays. Member 1 should pass the shared building data to this constructor.
2. The shared contract defines connections as directed. For a two-way corridor, Member 1 must store both directions.
3. `available == false` connections are ignored. Evacuation additionally ignores connections where `emergencyApproved == false`.
4. A route is computed from the supplied graph. The program cannot certify that a route is safe in a real emergency. Building administrators/fire-safety personnel must approve actual evacuation routes and refuge areas.
5. `assignVolunteer()` uses shortest-path distance on available connections. Skill matching is exact text matching, case-sensitive, with `ANY` as a wildcard. Keep skill labels consistent (for example `WHEELCHAIR`, `MEDICAL`, `DIRECTIONS`).
6. Request status transitions are restricted:
   - PENDING -> ACCEPTED or CANCELLED
   - ACCEPTED -> IN_PROGRESS or CANCELLED
   - IN_PROGRESS -> COMPLETED or CANCELLED
7. Compile with C++11 or later.

## DSA implementation
- Graph traversal/shortest path: Dijkstra's algorithm.
- Priority queue: custom binary min-heap used by Dijkstra.
- Volunteer and request lookup: hash tables with separate chaining.
- Storage: linked lists for volunteer and request records.
- Pending requests: linked FIFO queue.
