#include "Emergency.h"
#include <iostream>
using namespace std;

int main() {
    // Sample College Block A. This is illustrative test data, not an approved real evacuation plan.
    Location locations[] = {
        {1, 1, "Main Entrance", 0, ENTRANCE},
        {2, 1, "Main Corridor", 0, CORRIDOR},
        {3, 1, "Elevator", 0, ELEVATOR},
        {4, 1, "Room 101", 0, ROOM},
        {5, 1, "Staircase", 0, STAIRCASE},
        {6, 1, "Corridor 2", 1, CORRIDOR},
        {7, 1, "Room 201", 1, ROOM},
        {8, 1, "Emergency Exit", 0, EXIT},
        {9, 1, "Refuge Area", 1, REFUGE_AREA}
    };

    // Both directions are stored for every two-way passage.
    Connection connections[] = {
        {1,1,1,2,10,2,0,false,false,false,true,true,true},
        {2,1,2,1,10,2,0,false,false,false,true,true,true},
        {3,1,2,3,5,2,0,false,false,true,true,true,true},
        {4,1,3,2,5,2,0,false,false,true,true,true,true},
        {5,1,3,6,8,2,0,false,false,true,true,true,true},
        {6,1,6,3,8,2,0,false,false,true,true,true,true},
        {7,1,6,7,6,2,0,false,false,false,true,true,true},
        {8,1,7,6,6,2,0,false,false,false,true,true,true},
        {9,1,2,5,4,2,0,true,false,false,true,true,true},
        {10,1,5,2,4,2,0,true,false,false,true,true,true},
        {11,1,5,6,9,2,0,false,false,false,true,true,true},
        {12,1,6,5,9,2,0,false,false,false,true,true,true},
        {13,1,2,8,12,2,0,false,false,false,true,true,true},
        {14,1,8,2,12,2,0,false,false,false,true,true,true},
        {15,1,6,9,3,2,0,false,false,false,true,true,true},
        {16,1,9,6,3,2,0,false,false,false,true,true,true}
    };

    EmergencyHelpSystem system(1, locations, 9, connections, 16);

    cout << "===== ACCESSPULSE: MEMBER 2 DEMO =====\n";

    // 1. Emergency route
    RouteResult route = system.findEvacuationRoute(7);
    cout << "\n[EVACUATION]\n" << route.message << '\n';
    if (route.found) {
        cout << "Route: ";
        for (int i = 0; i < route.locationCount; ++i) {
            cout << route.locationIds[i];
            if (i + 1 < route.locationCount) cout << " -> ";
        }
        cout << "\nDestination ID: " << route.destinationLocationId
             << "\nDistance: " << route.totalDistance << " m\n";
    }

    // 2. Register volunteers
    Volunteer v1 = {101, 1, "Riya", "WHEELCHAIR", true, 2};
    Volunteer v2 = {102, 1, "Aman", "MEDICAL", true, 5};
    Volunteer v3 = {103, 1, "Kabir", "ANY", true, 8};

    system.registerVolunteer(v1);
    system.registerVolunteer(v2);
    system.registerVolunteer(v3);

    // 3. Create and assign a help request
    HelpRequest request = {501, 1, 7, -1, "WHEELCHAIR", PENDING};
    system.createHelpRequest(request);

    system.displayPendingQueue();
    VolunteerAssignmentResult assigned = system.assignVolunteer(501);
    cout << "\n[VOLUNTEER ASSIGNMENT]\n" << assigned.message << '\n';
    if (assigned.assigned)
        cout << "Volunteer ID: " << assigned.volunteerId
             << "\nEstimated distance: " << assigned.estimatedDistance << " m\n";

    // 4. Update request status
    system.updateRequestStatus(501, IN_PROGRESS);
    system.displayRequests();
    system.updateRequestStatus(501, COMPLETED);

    // 5. Save Member 2's records
    system.saveVolunteers("data/volunteers.txt");
    system.saveRequests("data/requests.txt");

    cout << "\n[FINAL STATE]\n";
    system.displayVolunteers();
    system.displayRequests();

    return 0;
}
