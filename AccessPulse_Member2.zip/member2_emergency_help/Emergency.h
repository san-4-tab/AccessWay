#ifndef ACCESSPULSE_EMERGENCY_H
#define ACCESSPULSE_EMERGENCY_H

#include "../common/AccessPulseData.h"
#include <string>

const int AP_MAX_ROUTE_LOCATIONS = 200;

struct RouteResult {
    bool found;
    int buildingId;
    int destinationLocationId;
    bool destinationIsExit; // false means refuge area
    float totalDistance;
    int locationCount;
    int locationIds[AP_MAX_ROUTE_LOCATIONS];
    std::string message;
};

struct VolunteerAssignmentResult {
    bool assigned;
    int requestId;
    int volunteerId;
    float estimatedDistance;
    std::string message;
};

class EmergencyHelpSystem {
private:
    struct VolunteerNode {
        Volunteer data;
        VolunteerNode* next;
    };

    struct RequestNode {
        HelpRequest data;
        RequestNode* next;
    };

    struct VolunteerHashNode {
        int id;
        VolunteerNode* record;
        VolunteerHashNode* next;
    };

    struct RequestHashNode {
        int id;
        RequestNode* record;
        RequestHashNode* next;
    };

    struct QueueNode {
        int requestId;
        QueueNode* next;
    };

    struct HeapItem {
        int locationId;
        float distance;
    };

    struct MinHeap {
        HeapItem* items;
        int size;
        int capacity;
    };

    int buildingId;
    Location* locations;
    int locationCount;
    Connection* connections;
    int connectionCount;

    VolunteerNode* volunteerHead;
    RequestNode* requestHead;
    VolunteerHashNode* volunteerTable[101];
    RequestHashNode* requestTable[101];

    QueueNode* queueFront;
    QueueNode* queueRear;

    int hashIndex(int id) const;
    int findLocationIndex(int locationId) const;
    VolunteerNode* findVolunteer(int volunteerId) const;
    RequestNode* findRequest(int requestId) const;

    void enqueue(int requestId);
    bool dequeue(int& requestId);
    bool isInPendingQueue(int requestId) const;

    void heapPush(MinHeap& heap, int locationId, float distance) const;
    HeapItem heapPop(MinHeap& heap) const;
    void runDijkstra(int sourceLocationId, float* distances,
                     int* previousLocation, bool emergencyOnly) const;
    bool reconstructRoute(int sourceLocationId, int destinationLocationId,
                          const int* previousLocation, RouteResult& result) const;
    void clearAll();

public:
    EmergencyHelpSystem(int buildingId, Location* locations, int locationCount,
                        Connection* connections, int connectionCount);
    ~EmergencyHelpSystem();

    EmergencyHelpSystem(const EmergencyHelpSystem&) = delete;
    EmergencyHelpSystem& operator=(const EmergencyHelpSystem&) = delete;

    // Emergency evacuation
    RouteResult findEvacuationRoute(int startLocationId) const;

    // Volunteer and visitor assistance
    bool registerVolunteer(const Volunteer& volunteer);
    bool setVolunteerAvailability(int volunteerId, bool available);
    bool createHelpRequest(const HelpRequest& request);
    VolunteerAssignmentResult assignVolunteer(int requestId);
    bool updateRequestStatus(int requestId, RequestStatus newStatus);

    void displayVolunteers() const;
    void displayRequests() const;
    void displayPendingQueue() const;

    // Text-file persistence for Member 2's own data.
    bool saveVolunteers(const std::string& filename) const;
    bool saveRequests(const std::string& filename) const;
    bool loadVolunteers(const std::string& filename);
    bool loadRequests(const std::string& filename);
};

const char* requestStatusName(RequestStatus status);

#endif
