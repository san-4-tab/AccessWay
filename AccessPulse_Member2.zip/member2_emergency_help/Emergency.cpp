#include "Emergency.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <limits>
#include <cstring>
#include <iomanip>

using namespace std;

const char* requestStatusName(RequestStatus status) {
    switch (status) {
        case PENDING: return "PENDING";
        case ACCEPTED: return "ACCEPTED";
        case IN_PROGRESS: return "IN_PROGRESS";
        case COMPLETED: return "COMPLETED";
        case CANCELLED: return "CANCELLED";
        default: return "UNKNOWN";
    }
}

EmergencyHelpSystem::EmergencyHelpSystem(int bId, Location* locs, int locCount,
                                         Connection* conns, int conCount)
    : buildingId(bId), locations(locs), locationCount(locCount),
      connections(conns), connectionCount(conCount),
      volunteerHead(NULL), requestHead(NULL),
      queueFront(NULL), queueRear(NULL) {
    for (int i = 0; i < 101; ++i) {
        volunteerTable[i] = NULL;
        requestTable[i] = NULL;
    }
}

EmergencyHelpSystem::~EmergencyHelpSystem() {
    clearAll();
}

int EmergencyHelpSystem::hashIndex(int id) const {
    int index = id % 101;
    return index < 0 ? index + 101 : index;
}

int EmergencyHelpSystem::findLocationIndex(int id) const {
    for (int i = 0; i < locationCount; ++i)
        if (locations[i].buildingId == buildingId && locations[i].locationId == id)
            return i;
    return -1;
}

EmergencyHelpSystem::VolunteerNode*
EmergencyHelpSystem::findVolunteer(int id) const {
    VolunteerHashNode* p = volunteerTable[hashIndex(id)];
    while (p) {
        if (p->id == id) return p->record;
        p = p->next;
    }
    return NULL;
}

EmergencyHelpSystem::RequestNode*
EmergencyHelpSystem::findRequest(int id) const {
    RequestHashNode* p = requestTable[hashIndex(id)];
    while (p) {
        if (p->id == id) return p->record;
        p = p->next;
    }
    return NULL;
}

void EmergencyHelpSystem::enqueue(int requestId) {
    QueueNode* node = new QueueNode{requestId, NULL};
    if (!queueRear) queueFront = queueRear = node;
    else {
        queueRear->next = node;
        queueRear = node;
    }
}

bool EmergencyHelpSystem::dequeue(int& requestId) {
    if (!queueFront) return false;
    QueueNode* temp = queueFront;
    requestId = temp->requestId;
    queueFront = queueFront->next;
    if (!queueFront) queueRear = NULL;
    delete temp;
    return true;
}

bool EmergencyHelpSystem::isInPendingQueue(int id) const {
    QueueNode* p = queueFront;
    while (p) {
        if (p->requestId == id) return true;
        p = p->next;
    }
    return false;
}

// Binary min-heap used by Dijkstra.
void EmergencyHelpSystem::heapPush(MinHeap& h, int locationId, float distance) const {
    if (h.size == h.capacity) {
        int newCapacity = h.capacity == 0 ? 16 : h.capacity * 2;
        HeapItem* bigger = new HeapItem[newCapacity];
        for (int i = 0; i < h.size; ++i) bigger[i] = h.items[i];
        delete[] h.items;
        h.items = bigger;
        h.capacity = newCapacity;
    }

    int i = h.size++;
    h.items[i] = {locationId, distance};
    while (i > 0) {
        int parent = (i - 1) / 2;
        if (h.items[parent].distance <= h.items[i].distance) break;
        HeapItem temp = h.items[parent];
        h.items[parent] = h.items[i];
        h.items[i] = temp;
        i = parent;
    }
}

EmergencyHelpSystem::HeapItem EmergencyHelpSystem::heapPop(MinHeap& h) const {
    HeapItem answer = h.items[0];
    h.items[0] = h.items[--h.size];
    int i = 0;
    while (true) {
        int left = 2 * i + 1, right = 2 * i + 2, smallest = i;
        if (left < h.size && h.items[left].distance < h.items[smallest].distance)
            smallest = left;
        if (right < h.size && h.items[right].distance < h.items[smallest].distance)
            smallest = right;
        if (smallest == i) break;
        HeapItem temp = h.items[i];
        h.items[i] = h.items[smallest];
        h.items[smallest] = temp;
        i = smallest;
    }
    return answer;
}

void EmergencyHelpSystem::runDijkstra(int sourceId, float* dist,
                                      int* previous, bool emergencyOnly) const {
    for (int i = 0; i < locationCount; ++i) {
        dist[i] = numeric_limits<float>::infinity();
        previous[i] = -1;
    }

    int source = findLocationIndex(sourceId);
    if (source == -1) return;

    bool* visited = new bool[locationCount];
    for (int i = 0; i < locationCount; ++i) visited[i] = false;

    MinHeap heap;
    heap.items = NULL;
    heap.size = 0;
    heap.capacity = 0;

    dist[source] = 0.0f;
    heapPush(heap, sourceId, 0.0f);

    while (heap.size > 0) {
        HeapItem current = heapPop(heap);
        int u = findLocationIndex(current.locationId);
        if (u == -1 || visited[u]) continue;
        if (current.distance > dist[u]) continue;
        visited[u] = true;

        // Connections are treated as directed, as specified in the shared contract.
        for (int e = 0; e < connectionCount; ++e) {
            const Connection& edge = connections[e];
            if (edge.buildingId != buildingId) continue;
            if (edge.fromLocationId != current.locationId) continue;
            if (!edge.available) continue;
            if (emergencyOnly && !edge.emergencyApproved) continue;

            int v = findLocationIndex(edge.toLocationId);
            if (v == -1 || visited[v] || edge.distance < 0) continue;

            float candidate = dist[u] + edge.distance;
            if (candidate < dist[v]) {
                dist[v] = candidate;
                previous[v] = current.locationId;
                heapPush(heap, edge.toLocationId, candidate);
            }
        }
    }

    delete[] visited;
    delete[] heap.items;
}

bool EmergencyHelpSystem::reconstructRoute(int sourceId, int destinationId,
                                           const int* previous,
                                           RouteResult& result) const {
    int* reversePath = new int[locationCount + 1];
    int count = 0;
    int current = destinationId;

    while (current != -1 && count <= locationCount) {
        reversePath[count++] = current;
        if (current == sourceId) break;

        int idx = findLocationIndex(current);
        if (idx == -1) break;
        current = previous[idx];
    }

    if (count == 0 || reversePath[count - 1] != sourceId ||
        count > AP_MAX_ROUTE_LOCATIONS) {
        delete[] reversePath;
        return false;
    }

    result.locationCount = count;
    for (int i = 0; i < count; ++i)
        result.locationIds[i] = reversePath[count - 1 - i];

    delete[] reversePath;
    return true;
}

RouteResult EmergencyHelpSystem::findEvacuationRoute(int startId) const {
    RouteResult result;
    result.found = false;
    result.buildingId = buildingId;
    result.destinationLocationId = -1;
    result.destinationIsExit = false;
    result.totalDistance = 0;
    result.locationCount = 0;
    result.message = "No emergency-approved route to an exit or refuge area was found.";

    int startIndex = findLocationIndex(startId);
    if (startIndex == -1) {
        result.message = "Starting location does not exist in this building.";
        return result;
    }

    float* dist = new float[locationCount];
    int* previous = new int[locationCount];
    runDijkstra(startId, dist, previous, true);

    int bestIndex = -1;
    // Prefer the closest reachable EXIT; if none is reachable, use a refuge area.
    for (int pass = 0; pass < 2 && bestIndex == -1; ++pass) {
        for (int i = 0; i < locationCount; ++i) {
            if (locations[i].buildingId != buildingId) continue;
            bool desired = (pass == 0)
                ? locations[i].type == EXIT
                : locations[i].type == REFUGE_AREA;
            if (desired && dist[i] < numeric_limits<float>::infinity()) {
                if (bestIndex == -1 || dist[i] < dist[bestIndex])
                    bestIndex = i;
            }
        }
    }

    if (bestIndex != -1) {
        result.found = reconstructRoute(startId, locations[bestIndex].locationId,
                                        previous, result);
        if (result.found) {
            result.destinationLocationId = locations[bestIndex].locationId;
            result.destinationIsExit = locations[bestIndex].type == EXIT;
            result.totalDistance = dist[bestIndex];
            result.message = result.destinationIsExit
                ? "Safe route to the nearest reachable emergency exit found."
                : "No reachable exit was found; route to a reachable refuge area found.";
        }
    }

    delete[] dist;
    delete[] previous;
    return result;
}

bool EmergencyHelpSystem::registerVolunteer(const Volunteer& v) {
    if (v.buildingId != buildingId || v.volunteerId <= 0 ||
        findLocationIndex(v.currentLocationId) == -1 ||
        findVolunteer(v.volunteerId) != NULL)
        return false;

    VolunteerNode* record = new VolunteerNode{v, volunteerHead};
    volunteerHead = record;

    int index = hashIndex(v.volunteerId);
    VolunteerHashNode* hashNode = new VolunteerHashNode{v.volunteerId, record,
                                                         volunteerTable[index]};
    volunteerTable[index] = hashNode;
    return true;
}

bool EmergencyHelpSystem::setVolunteerAvailability(int id, bool available) {
    VolunteerNode* v = findVolunteer(id);
    if (!v) return false;
    v->data.available = available;
    return true;
}

bool EmergencyHelpSystem::createHelpRequest(const HelpRequest& r) {
    if (r.buildingId != buildingId || r.requestId <= 0 ||
        findLocationIndex(r.visitorLocationId) == -1 ||
        findRequest(r.requestId) != NULL)
        return false;

    HelpRequest copy = r;
    copy.assignedVolunteerId = -1;
    copy.status = PENDING;

    RequestNode* record = new RequestNode{copy, requestHead};
    requestHead = record;

    int index = hashIndex(copy.requestId);
    RequestHashNode* hashNode = new RequestHashNode{copy.requestId, record,
                                                     requestTable[index]};
    requestTable[index] = hashNode;
    enqueue(copy.requestId);
    return true;
}

VolunteerAssignmentResult EmergencyHelpSystem::assignVolunteer(int requestId) {
    VolunteerAssignmentResult result;
    result.assigned = false;
    result.requestId = requestId;
    result.volunteerId = -1;
    result.estimatedDistance = -1;
    result.message = "Request not found.";

    RequestNode* request = findRequest(requestId);
    if (!request) return result;

    if (request->data.status != PENDING) {
        result.message = "Only pending requests can be assigned.";
        return result;
    }

    float* dist = new float[locationCount];
    int* previous = new int[locationCount];
    runDijkstra(request->data.visitorLocationId, dist, previous, false);

    VolunteerNode* best = NULL;
    float bestDistance = numeric_limits<float>::infinity();

    for (VolunteerNode* v = volunteerHead; v; v = v->next) {
        if (!v->data.available || v->data.buildingId != buildingId) continue;

        bool skillMatches = (v->data.assistanceType == request->data.helpType ||
                             v->data.assistanceType == "ANY");
        if (!skillMatches) continue;

        int volunteerLocation = findLocationIndex(v->data.currentLocationId);
        if (volunteerLocation == -1) continue;

        if (dist[volunteerLocation] < bestDistance) {
            bestDistance = dist[volunteerLocation];
            best = v;
        }
    }

    if (best) {
        best->data.available = false;
        request->data.assignedVolunteerId = best->data.volunteerId;
        request->data.status = ACCEPTED;
        result.assigned = true;
        result.volunteerId = best->data.volunteerId;
        result.estimatedDistance = bestDistance;
        result.message = "Nearest available volunteer with a matching assistance type assigned.";
    } else {
        result.message = "No available matching volunteer is reachable. Request remains pending.";
    }

    delete[] dist;
    delete[] previous;
    return result;
}

bool EmergencyHelpSystem::updateRequestStatus(int requestId, RequestStatus newStatus) {
    RequestNode* request = findRequest(requestId);
    if (!request) return false;

    RequestStatus oldStatus = request->data.status;

    // Restrict status changes to sensible forward transitions.
    bool valid = false;
    if (oldStatus == PENDING)
        valid = (newStatus == ACCEPTED || newStatus == CANCELLED);
    else if (oldStatus == ACCEPTED)
        valid = (newStatus == IN_PROGRESS || newStatus == CANCELLED);
    else if (oldStatus == IN_PROGRESS)
        valid = (newStatus == COMPLETED || newStatus == CANCELLED);

    if (!valid) return false;

    request->data.status = newStatus;

    if (newStatus == COMPLETED || newStatus == CANCELLED) {
        int volunteerId = request->data.assignedVolunteerId;
        if (volunteerId != -1) {
            VolunteerNode* v = findVolunteer(volunteerId);
            if (v) v->data.available = true;
        }
    }
    return true;
}

void EmergencyHelpSystem::displayVolunteers() const {
    cout << "\n--- VOLUNTEERS ---\n";
    if (!volunteerHead) { cout << "No volunteers registered.\n"; return; }
    for (VolunteerNode* p = volunteerHead; p; p = p->next) {
        cout << "ID: " << p->data.volunteerId
             << " | Name: " << p->data.volunteerName
             << " | Skill: " << p->data.assistanceType
             << " | Location: " << p->data.currentLocationId
             << " | " << (p->data.available ? "Available" : "Busy") << '\n';
    }
}

void EmergencyHelpSystem::displayRequests() const {
    cout << "\n--- HELP REQUESTS ---\n";
    if (!requestHead) { cout << "No requests found.\n"; return; }
    for (RequestNode* p = requestHead; p; p = p->next) {
        cout << "Request: " << p->data.requestId
             << " | Visitor location: " << p->data.visitorLocationId
             << " | Help: " << p->data.helpType
             << " | Volunteer: " << p->data.assignedVolunteerId
             << " | Status: " << requestStatusName(p->data.status) << '\n';
    }
}

void EmergencyHelpSystem::displayPendingQueue() const {
    cout << "\n--- PENDING REQUEST QUEUE (FIFO) ---\n";
    if (!queueFront) { cout << "Queue is empty.\n"; return; }
    for (QueueNode* p = queueFront; p; p = p->next) {
        RequestNode* r = findRequest(p->requestId);
        if (r && r->data.status == PENDING)
            cout << p->requestId << " ";
    }
    cout << '\n';
}

bool EmergencyHelpSystem::saveVolunteers(const string& filename) const {
    ofstream out(filename.c_str());
    if (!out) return false;
    // Pipe-separated text; names/skills should not contain '|'.
    for (VolunteerNode* p = volunteerHead; p; p = p->next) {
        const Volunteer& v = p->data;
        out << v.volunteerId << '|' << v.buildingId << '|'
            << v.volunteerName << '|' << v.assistanceType << '|'
            << v.available << '|' << v.currentLocationId << '\n';
    }
    return true;
}

bool EmergencyHelpSystem::saveRequests(const string& filename) const {
    ofstream out(filename.c_str());
    if (!out) return false;
    for (RequestNode* p = requestHead; p; p = p->next) {
        const HelpRequest& r = p->data;
        out << r.requestId << '|' << r.buildingId << '|'
            << r.visitorLocationId << '|' << r.assignedVolunteerId << '|'
            << r.helpType << '|' << static_cast<int>(r.status) << '\n';
    }
    return true;
}

bool EmergencyHelpSystem::loadVolunteers(const string& filename) {
    ifstream in(filename.c_str());
    if (!in) return false;
    string line;
    while (getline(in, line)) {
        if (line.empty()) continue;
        stringstream ss(line);
        string field;
        Volunteer v;
        if (!getline(ss, field, '|')) continue; v.volunteerId = stoi(field);
        if (!getline(ss, field, '|')) continue; v.buildingId = stoi(field);
        if (!getline(ss, v.volunteerName, '|')) continue;
        if (!getline(ss, v.assistanceType, '|')) continue;
        if (!getline(ss, field, '|')) continue; v.available = (stoi(field) != 0);
        if (!getline(ss, field, '|')) continue; v.currentLocationId = stoi(field);
        registerVolunteer(v);
    }
    return true;
}

bool EmergencyHelpSystem::loadRequests(const string& filename) {
    ifstream in(filename.c_str());
    if (!in) return false;
    string line;
    while (getline(in, line)) {
        if (line.empty()) continue;
        stringstream ss(line);
        string field;
        HelpRequest r;
        if (!getline(ss, field, '|')) continue; r.requestId = stoi(field);
        if (!getline(ss, field, '|')) continue; r.buildingId = stoi(field);
        if (!getline(ss, field, '|')) continue; r.visitorLocationId = stoi(field);
        if (!getline(ss, field, '|')) continue; r.assignedVolunteerId = stoi(field);
        if (!getline(ss, r.helpType, '|')) continue;
        if (!getline(ss, field, '|')) continue;
        int status = stoi(field);
        if (status < PENDING || status > CANCELLED) continue;
        r.status = static_cast<RequestStatus>(status);
        if (r.buildingId != buildingId || findRequest(r.requestId)) continue;

        RequestNode* record = new RequestNode{r, requestHead};
        requestHead = record;
        int index = hashIndex(r.requestId);
        requestTable[index] = new RequestHashNode{r.requestId, record, requestTable[index]};
        if (r.status == PENDING) enqueue(r.requestId);
    }
    return true;
}

void EmergencyHelpSystem::clearAll() {
    while (volunteerHead) {
        VolunteerNode* next = volunteerHead->next;
        delete volunteerHead;
        volunteerHead = next;
    }
    while (requestHead) {
        RequestNode* next = requestHead->next;
        delete requestHead;
        requestHead = next;
    }
    while (queueFront) {
        QueueNode* next = queueFront->next;
        delete queueFront;
        queueFront = next;
    }
    queueRear = NULL;

    for (int i = 0; i < 101; ++i) {
        while (volunteerTable[i]) {
            VolunteerHashNode* next = volunteerTable[i]->next;
            delete volunteerTable[i];
            volunteerTable[i] = next;
        }
        while (requestTable[i]) {
            RequestHashNode* next = requestTable[i]->next;
            delete requestTable[i];
            requestTable[i] = next;
        }
    }
}
