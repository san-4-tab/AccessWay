# AccessPulse – Member 1: Building Blueprint & Navigation

## Compile and run
From the `AccessPulse_Member1` folder:

```bash
g++ -std=c++11 member1_navigation/Navigation.cpp member1_navigation/test_navigation.cpp -o member1_demo
./member1_demo
```

## Implemented functions
- `addBuilding(const Building&)`
- `addLocation(const Location&)`
- `addConnection(const Connection&)`
- `setConnectionAvailability(buildingId, connectionId, available)`
- `removeConnection(buildingId, connectionId)`
- `findAccessibleRoute(buildingId, start, destination, profile)`
- `findAlternativeRoutes(buildingId, start, destination, profile)`\n- `displayReachableLocationsBFS(buildingId, start, profile)`
- `exportLocations(buildingId, outputArray, capacity)` and `exportConnections(...)` for passing graph arrays to Member 2.
- `displayBuildings()`, `displayBuildingBlueprint(buildingId)`
- `saveBuildings`, `saveLocations`, `saveConnections`
- `loadBuildings`, `loadLocations`, `loadConnections`

## DSA used
- Graph represented by directed connections and temporary adjacency lists.
- Linked lists for building, location and connection records.
- Dijkstra shortest path with a custom binary min-heap.
- BFS traversal to list all locations reachable under a selected mobility profile.\n- Alternative route calculation by temporarily excluding each edge of the primary route and finding the best distinct route.

## Accessibility policy used in this demo
These are configurable illustrative project rules, not legal/medical standards:
- Wheelchair: exclude stairs, connections narrower than 0.90 m (when width is supplied), and slope above 8%.
- Crutches: exclude stairs and slope above 12%.
- Hand disability: prefer/require automatic doors in this demo.
- Limited mobility: exclude stairs and slope above 10%.
- General: use any available connection.

If width is recorded as 0, the demo treats it as unspecified and does not reject the edge based on width. Tune thresholds with your faculty/building accessibility guidance.

## Integration with Member 2
The shared structures in `common/AccessPulseData.h` are copied from the agreed contract. Member 2's `EmergencyHelpSystem` accepts `Location[]` and `Connection[]` arrays. Member 1 stores records in linked lists and provides `exportLocations()` and `exportConnections()` to copy one building's records into arrays for Member 2.

The demo saves to `data/buildings.txt`, `data/locations.txt` and `data/connections.txt`.\n\nThe shared contract defines connections as directed. Add a reverse connection record for every bidirectional corridor, ramp or doorway.

## Safety limitation
This is a student project route planner, not a certified life-safety system. Real evacuation routes, exits, refuge areas and accessibility thresholds must be validated by qualified building/fire-safety personnel.
