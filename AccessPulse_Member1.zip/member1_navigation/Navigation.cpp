#include "Navigation.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <limits>
#include <cmath>

using namespace std;

const char* mobilityProfileName(MobilityProfile p) {
    switch (p) {
        case WHEELCHAIR: return "WHEELCHAIR";
        case CRUTCHES: return "CRUTCHES";
        case HAND_DISABILITY: return "HAND_DISABILITY";
        case LIMITED_MOBILITY: return "LIMITED_MOBILITY";
        case GENERAL: return "GENERAL";
        default: return "UNKNOWN";
    }
}

NavigationSystem::NavigationSystem()
    : buildingHead(NULL), locationHead(NULL), connectionHead(NULL),
      buildingCount(0), locationCount(0), connectionCount(0) {}

NavigationSystem::~NavigationSystem() { clear(); }

bool NavigationSystem::buildingExists(int id) const {
    for (BuildingNode* p=buildingHead; p; p=p->next)
        if (p->data.buildingId==id) return true;
    return false;
}

NavigationSystem::LocationNode*
NavigationSystem::findLocation(int bId, int lId) const {
    for (LocationNode* p=locationHead; p; p=p->next)
        if (p->data.buildingId==bId && p->data.locationId==lId) return p;
    return NULL;
}

int NavigationSystem::countLocations(int bId) const {
    int n=0;
    for (LocationNode* p=locationHead; p; p=p->next)
        if (p->data.buildingId==bId) ++n;
    return n;
}

int NavigationSystem::countConnections(int bId) const {
    int n=0;
    for (ConnectionNode* p=connectionHead; p; p=p->next)
        if (p->data.buildingId==bId) ++n;
    return n;
}

int NavigationSystem::hashLocation(int bId, int lId) const {
    // Stable combined key helper; the graph itself is stored with linked adjacency lists.
    return (bId * 1009 + lId) % 1000003;
}

bool NavigationSystem::addBuilding(const Building& b) {
    if (b.buildingId<=0 || b.totalFloors<1 || buildingExists(b.buildingId))
        return false;
    buildingHead = new BuildingNode{b, buildingHead};
    ++buildingCount;
    return true;
}

bool NavigationSystem::addLocation(const Location& l) {
    if (!buildingExists(l.buildingId) || l.locationId<=0 ||
        findLocation(l.buildingId,l.locationId)!=NULL)
        return false;
    locationHead = new LocationNode{l,locationHead};
    ++locationCount;
    return true;
}

bool NavigationSystem::addConnection(const Connection& c) {
    if (!buildingExists(c.buildingId) || c.connectionId<=0 ||
        !findLocation(c.buildingId,c.fromLocationId) ||
        !findLocation(c.buildingId,c.toLocationId) ||
        c.fromLocationId==c.toLocationId || c.distance<0 ||
        c.width<0 || c.slope<0)
        return false;

    for (ConnectionNode* p=connectionHead; p; p=p->next)
        if (p->data.buildingId==c.buildingId &&
            p->data.connectionId==c.connectionId) return false;

    connectionHead = new ConnectionNode{c,connectionHead};
    ++connectionCount;
    return true;
}

bool NavigationSystem::setConnectionAvailability(int bId,int cId,bool available) {
    for (ConnectionNode* p=connectionHead;p;p=p->next) {
        if (p->data.buildingId==bId && p->data.connectionId==cId) {
            p->data.available=available;
            return true;
        }
    }
    return false;
}

bool NavigationSystem::removeConnection(int bId,int cId) {
    ConnectionNode* p=connectionHead;
    ConnectionNode* prev=NULL;
    while (p) {
        if (p->data.buildingId==bId && p->data.connectionId==cId) {
            if (prev) prev->next=p->next; else connectionHead=p->next;
            delete p;
            --connectionCount;
            return true;
        }
        prev=p; p=p->next;
    }
    return false;
}

void NavigationSystem::heapPush(MinHeap& h,int id,float d) const {
    if (h.size==h.capacity) {
        int cap=h.capacity==0?16:h.capacity*2;
        HeapItem* a=new HeapItem[cap];
        for(int i=0;i<h.size;++i) a[i]=h.items[i];
        delete[] h.items; h.items=a; h.capacity=cap;
    }
    int i=h.size++;
    h.items[i]={id,d};
    while(i>0) {
        int par=(i-1)/2;
        if(h.items[par].distance<=h.items[i].distance) break;
        HeapItem t=h.items[par]; h.items[par]=h.items[i]; h.items[i]=t;
        i=par;
    }
}

NavigationSystem::HeapItem NavigationSystem::heapPop(MinHeap& h) const {
    HeapItem out=h.items[0];
    h.items[0]=h.items[--h.size];
    int i=0;
    while(true) {
        int l=2*i+1,r=2*i+2,s=i;
        if(l<h.size && h.items[l].distance<h.items[s].distance) s=l;
        if(r<h.size && h.items[r].distance<h.items[s].distance) s=r;
        if(s==i) break;
        HeapItem t=h.items[i]; h.items[i]=h.items[s]; h.items[s]=t; i=s;
    }
    return out;
}

void NavigationSystem::appendWarning(string& all,const string& w) const {
    if(w.empty()) return;
    if(!all.empty()) all += "; ";
    all += w;
}

bool NavigationSystem::connectionAllowed(const Connection& e,
                                          MobilityProfile profile,
                                          string& warning) const {
    warning="";
    if(!e.available) { warning="Unavailable connection avoided"; return false; }

    // These are configurable demo policies, not statutory accessibility standards.
    const float MIN_CLEAR_WIDTH=0.90f; // metres, example project threshold
    const float MAX_GENTLE_SLOPE=8.0f; // percent, example project threshold

    if(profile==WHEELCHAIR) {
        if(e.hasStairs) { warning="Stairs avoided for wheelchair access"; return false; }
        if(e.width>0 && e.width<MIN_CLEAR_WIDTH) {
            warning="Narrow connection avoided for wheelchair access"; return false;
        }
        if(e.slope>MAX_GENTLE_SLOPE) {
            warning="Steep connection avoided for wheelchair access"; return false;
        }
    } else if(profile==CRUTCHES) {
        if(e.hasStairs) {
            warning="Stair connection avoided where possible for crutch users";
            return false;
        }
        if(e.slope>12.0f) {
            warning="Steep connection avoided for crutch users"; return false;
        }
    } else if(profile==HAND_DISABILITY) {
        if(!e.automaticDoor) {
            warning="Manual-door connection avoided for hand-disability profile";
            return false;
        }
    } else if(profile==LIMITED_MOBILITY) {
        if(e.hasStairs) {
            warning="Stairs avoided for limited-mobility profile"; return false;
        }
        if(e.slope>10.0f) {
            warning="Steep connection avoided for limited-mobility profile"; return false;
        }
    }
    return true;
}

NavigationRoute NavigationSystem::shortestRoute(int bId,int startId,int endId,
                                                 MobilityProfile profile,
                                                 int bannedConnectionId) const {
    NavigationRoute result;
    result.found=false; result.buildingId=bId; result.locationCount=0;
    result.totalDistance=0;
    result.message="No accessible route was found.";
    result.warnings="";

    if(!buildingExists(bId)) {
        result.message="Building ID does not exist."; return result;
    }
    if(!findLocation(bId,startId) || !findLocation(bId,endId)) {
        result.message="Starting or destination location does not exist in this building.";
        return result;
    }
    if(startId==endId) {
        result.found=true; result.locationIds[0]=startId; result.locationCount=1;
        result.message="You are already at the destination."; return result;
    }

    int n=countLocations(bId);
    if(n<=0 || n>AP1_MAX_ROUTE_LOCATIONS) {
        result.message="Building has no locations or exceeds the supported route size.";
        return result;
    }

    // Build a temporary compact location index and adjacency lists for this building.
    int* ids=new int[n];
    int k=0;
    for(LocationNode* p=locationHead;p;p=p->next)
        if(p->data.buildingId==bId) ids[k++]=p->data.locationId;

    AdjNode** adj=new AdjNode*[n];
    for(int i=0;i<n;++i) adj[i]=NULL;

    for(ConnectionNode* c=connectionHead;c;c=c->next) {
        if(c->data.buildingId!=bId || c->data.connectionId==bannedConnectionId) continue;
        int u=-1;
        for(int i=0;i<n;++i) if(ids[i]==c->data.fromLocationId) {u=i;break;}
        if(u==-1) continue;
        AdjNode* a=new AdjNode{c->data.connectionId,adj[u]};
        adj[u]=a;
    }

    int source=-1,dest=-1;
    for(int i=0;i<n;++i) {
        if(ids[i]==startId) source=i;
        if(ids[i]==endId) dest=i;
    }

    float* dist=new float[n];
    int* prev=new int[n];
    bool* visited=new bool[n];
    for(int i=0;i<n;++i) {dist[i]=numeric_limits<float>::infinity();prev[i]=-1;visited[i]=false;}

    MinHeap heap; heap.items=NULL; heap.size=0; heap.capacity=0;
    dist[source]=0; heapPush(heap,startId,0);

    while(heap.size>0) {
        HeapItem item=heapPop(heap);
        int u=-1;
        for(int i=0;i<n;++i) if(ids[i]==item.locationId) {u=i;break;}
        if(u<0 || visited[u] || item.distance>dist[u]) continue;
        visited[u]=true;
        if(u==dest) break;

        for(AdjNode* a=adj[u];a;a=a->next) {
            ConnectionNode* edge=NULL;
            for(ConnectionNode* c=connectionHead;c;c=c->next)
                if(c->data.buildingId==bId && c->data.connectionId==a->connectionIndex) {
                    edge=c; break;
                }
            if(!edge) continue;
            string warning;
            if(!connectionAllowed(edge->data,profile,warning)) {
                appendWarning(result.warnings,warning); continue;
            }

            int v=-1;
            for(int i=0;i<n;++i) if(ids[i]==edge->data.toLocationId) {v=i;break;}
            if(v<0 || visited[v]) continue;

            float cost=edge->data.distance;
            // Small preference penalties for less convenient but still permitted links.
            if(profile==CRUTCHES && edge->data.hasStairs) cost+=5.0f;
            if(profile==LIMITED_MOBILITY && edge->data.hasStairs) cost+=8.0f;
            if(cost<0) continue;
            if(dist[u]+cost<dist[v]) {
                dist[v]=dist[u]+cost; prev[v]=u;
                heapPush(heap,ids[v],dist[v]);
            }
        }
    }

    if(dist[dest]<numeric_limits<float>::infinity()) {
        int* rev=new int[n+1]; int count=0,cur=dest;
        while(cur!=-1 && count<=n) {rev[count++]=cur;if(cur==source)break;cur=prev[cur];}
        if(count>0 && rev[count-1]==source && count<=AP1_MAX_ROUTE_LOCATIONS) {
            result.found=true; result.locationCount=count;
            for(int i=0;i<count;++i) result.locationIds[i]=ids[rev[count-1-i]];
            result.totalDistance=dist[dest];
            result.message="Accessible route found for the selected mobility profile.";
        }
        delete[] rev;
    }

    for(int i=0;i<n;++i) {
        AdjNode* a=adj[i];
        while(a) {AdjNode* next=a->next;delete a;a=next;}
    }
    delete[] adj; delete[] ids; delete[] dist; delete[] prev;
    delete[] visited; delete[] heap.items;
    return result;
}

NavigationRoute NavigationSystem::findAccessibleRoute(int bId,int s,int d,
                                                       MobilityProfile p) const {
    return shortestRoute(bId,s,d,p,-1);
}

AlternativeRoutes NavigationSystem::findAlternativeRoutes(int bId,int s,int d,
                                                             MobilityProfile p) const {
    AlternativeRoutes out;
    out.primary=findAccessibleRoute(bId,s,d,p);
    out.alternativeFound=false;
    out.alternative.found=false;
    out.alternative.message="No alternative route found.";
    if(!out.primary.found) return out;

    float best=numeric_limits<float>::infinity();
    // Try banning each connection on the primary path; choose the shortest distinct route.
    for(int i=0;i<out.primary.locationCount-1;++i) {
        int from=out.primary.locationIds[i],to=out.primary.locationIds[i+1];
        for(ConnectionNode* c=connectionHead;c;c=c->next) {
            if(c->data.buildingId!=bId || c->data.fromLocationId!=from ||
               c->data.toLocationId!=to) continue;
            NavigationRoute candidate=shortestRoute(bId,s,d,p,c->data.connectionId);
            if(candidate.found && candidate.totalDistance<best) {
                best=candidate.totalDistance;
                out.alternative=candidate;
                out.alternativeFound=true;
            }
        }
    }
    if(out.alternativeFound)
        out.alternative.message="Alternative accessible route found.";
    return out;
}

int NavigationSystem::exportLocations(int bId,Location* output,int capacity) const {
    if(!output || capacity<=0 || !buildingExists(bId)) return 0;
    int count=0;
    for(LocationNode* p=locationHead;p && count<capacity;p=p->next)
        if(p->data.buildingId==bId) output[count++]=p->data;
    return count;
}

int NavigationSystem::exportConnections(int bId,Connection* output,int capacity) const {
    if(!output || capacity<=0 || !buildingExists(bId)) return 0;
    int count=0;
    for(ConnectionNode* p=connectionHead;p && count<capacity;p=p->next)
        if(p->data.buildingId==bId) output[count++]=p->data;
    return count;
}

void NavigationSystem::displayReachableLocationsBFS(int bId,int startId,
                                                       MobilityProfile profile) const {
    if(!buildingExists(bId) || !findLocation(bId,startId)) {
        cout<<"Building or starting location not found.\n";
        return;
    }
    int n=countLocations(bId);
    int* ids=new int[n];
    bool* visited=new bool[n];
    int* queue=new int[n];
    int k=0;
    for(LocationNode* p=locationHead;p;p=p->next) if(p->data.buildingId==bId) {
        ids[k]=p->data.locationId; visited[k]=false; ++k;
    }
    int source=-1;
    for(int i=0;i<n;++i) if(ids[i]==startId) {source=i;break;}
    int front=0,rear=0;
    queue[rear++]=source; visited[source]=true;

    cout<<"BFS reachable locations: ";
    while(front<rear) {
        int u=queue[front++];
        cout<<ids[u]<<" ";
        for(ConnectionNode* edge=connectionHead;edge;edge=edge->next) {
            const Connection& c=edge->data;
            if(c.buildingId!=bId || c.fromLocationId!=ids[u]) continue;
            string warning;
            if(!connectionAllowed(c,profile,warning)) continue;
            int v=-1;
            for(int i=0;i<n;++i) if(ids[i]==c.toLocationId) {v=i;break;}
            if(v!=-1 && !visited[v]) {
                visited[v]=true;
                queue[rear++]=v;
            }
        }
    }
    cout<<'\n';
    delete[] ids; delete[] visited; delete[] queue;
}

void NavigationSystem::displayBuildings() const {
    cout<<"\n--- REGISTERED BUILDINGS ---\n";
    if(!buildingHead) {cout<<"No buildings registered.\n";return;}
    for(BuildingNode* p=buildingHead;p;p=p->next)
        cout<<"ID: "<<p->data.buildingId<<" | "<<p->data.buildingName
            <<" | Floors: "<<p->data.totalFloors<<'\n';
}

void NavigationSystem::displayBuildingBlueprint(int bId) const {
    if(!buildingExists(bId)) {cout<<"Building not found.\n";return;}
    cout<<"\n--- BUILDING BLUEPRINT: "<<bId<<" ---\n";
    for(LocationNode* p=locationHead;p;p=p->next) if(p->data.buildingId==bId)
        cout<<"Location "<<p->data.locationId<<" | "<<p->data.locationName
            <<" | Floor "<<p->data.floor<<" | Type "<<static_cast<int>(p->data.type)<<'\n';
    cout<<"Connections (directed):\n";
    for(ConnectionNode* p=connectionHead;p;p=p->next) if(p->data.buildingId==bId)
        cout<<p->data.fromLocationId<<" -> "<<p->data.toLocationId
            <<" | "<<p->data.distance<<" m | "
            <<(p->data.available?"Available":"Unavailable")<<'\n';
}

bool NavigationSystem::saveBuildings(const string& file) const {
    ofstream out(file.c_str()); if(!out)return false;
    for(BuildingNode* p=buildingHead;p;p=p->next)
        out<<p->data.buildingId<<'|'<<p->data.buildingName<<'|'<<p->data.totalFloors<<'\n';
    return true;
}
bool NavigationSystem::saveLocations(const string& file) const {
    ofstream out(file.c_str()); if(!out)return false;
    for(LocationNode* p=locationHead;p;p=p->next)
        out<<p->data.locationId<<'|'<<p->data.buildingId<<'|'<<p->data.locationName
           <<'|'<<p->data.floor<<'|'<<static_cast<int>(p->data.type)<<'\n';
    return true;
}
bool NavigationSystem::saveConnections(const string& file) const {
    ofstream out(file.c_str()); if(!out)return false;
    for(ConnectionNode* p=connectionHead;p;p=p->next) {
        const Connection& c=p->data;
        out<<c.connectionId<<'|'<<c.buildingId<<'|'<<c.fromLocationId<<'|'<<c.toLocationId
           <<'|'<<c.distance<<'|'<<c.width<<'|'<<c.slope<<'|'<<c.hasStairs
           <<'|'<<c.hasRamp<<'|'<<c.hasElevator<<'|'<<c.automaticDoor
           <<'|'<<c.available<<'|'<<c.emergencyApproved<<'\n';
    }
    return true;
}

bool NavigationSystem::loadBuildings(const string& file) {
    ifstream in(file.c_str()); if(!in)return false;
    string line;
    while(getline(in,line)) {
        if(line.empty())continue;
        stringstream ss(line);string x;Building b;
        if(!getline(ss,x,'|'))continue;b.buildingId=stoi(x);
        if(!getline(ss,b.buildingName,'|'))continue;
        if(!getline(ss,x,'|'))continue;b.totalFloors=stoi(x);
        addBuilding(b);
    }
    return true;
}
bool NavigationSystem::loadLocations(const string& file) {
    ifstream in(file.c_str()); if(!in)return false;
    string line;
    while(getline(in,line)) {
        if(line.empty())continue;
        stringstream ss(line);string x;Location l;
        if(!getline(ss,x,'|'))continue;l.locationId=stoi(x);
        if(!getline(ss,x,'|'))continue;l.buildingId=stoi(x);
        if(!getline(ss,l.locationName,'|'))continue;
        if(!getline(ss,x,'|'))continue;l.floor=stoi(x);
        if(!getline(ss,x,'|'))continue;int t=stoi(x);
        if(t<ENTRANCE||t>JUNCTION)continue;
        l.type=static_cast<LocationType>(t);addLocation(l);
    }
    return true;
}
bool NavigationSystem::loadConnections(const string& file) {
    ifstream in(file.c_str()); if(!in)return false;
    string line;
    while(getline(in,line)) {
        if(line.empty())continue;
        stringstream ss(line);string x;Connection c;
        if(!getline(ss,x,'|'))continue;c.connectionId=stoi(x);
        if(!getline(ss,x,'|'))continue;c.buildingId=stoi(x);
        if(!getline(ss,x,'|'))continue;c.fromLocationId=stoi(x);
        if(!getline(ss,x,'|'))continue;c.toLocationId=stoi(x);
        if(!getline(ss,x,'|'))continue;c.distance=stof(x);
        if(!getline(ss,x,'|'))continue;c.width=stof(x);
        if(!getline(ss,x,'|'))continue;c.slope=stof(x);
        if(!getline(ss,x,'|'))continue;c.hasStairs=stoi(x)!=0;
        if(!getline(ss,x,'|'))continue;c.hasRamp=stoi(x)!=0;
        if(!getline(ss,x,'|'))continue;c.hasElevator=stoi(x)!=0;
        if(!getline(ss,x,'|'))continue;c.automaticDoor=stoi(x)!=0;
        if(!getline(ss,x,'|'))continue;c.available=stoi(x)!=0;
        if(!getline(ss,x,'|'))continue;c.emergencyApproved=stoi(x)!=0;
        addConnection(c);
    }
    return true;
}

void NavigationSystem::clear() {
    while(buildingHead){BuildingNode*n=buildingHead->next;delete buildingHead;buildingHead=n;}
    while(locationHead){LocationNode*n=locationHead->next;delete locationHead;locationHead=n;}
    while(connectionHead){ConnectionNode*n=connectionHead->next;delete connectionHead;connectionHead=n;}
}
