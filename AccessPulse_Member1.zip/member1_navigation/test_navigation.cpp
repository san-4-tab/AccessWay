#include "Navigation.h"
#include <iostream>
using namespace std;

int main() {
    NavigationSystem nav;

    Building b1={1,"College Block A",2};
    Building b2={2,"Library Block",1};
    nav.addBuilding(b1);
    nav.addBuilding(b2);

    // College Block A sample locations
    Location a[] = {
        {1,1,"Main Entrance",0,ENTRANCE},
        {2,1,"Main Corridor",0,CORRIDOR},
        {3,1,"Elevator",0,ELEVATOR},
        {4,1,"Room 101",0,ROOM},
        {5,1,"Staircase",0,STAIRCASE},
        {6,1,"Corridor 2",1,CORRIDOR},
        {7,1,"Room 201",1,ROOM},
        {8,1,"Emergency Exit",0,EXIT},
        {9,1,"Ramp Junction",0,RAMP}
    };
    for(int i=0;i<9;++i) nav.addLocation(a[i]);

    // Library Block location demonstrates multiple-building support.
    Location lib={1,2,"Library Entrance",0,ENTRANCE};
    nav.addLocation(lib);

    Connection e[] = {
        {1,1,1,2,10,1.5,0,false,false,false,true,true,true},
        {2,1,2,3,5,1.2,0,false,false,true,true,true,true},
        {3,1,3,6,8,1.2,0,false,false,true,true,true,true},
        {4,1,6,7,6,1.2,0,false,false,false,true,true,true},
        {5,1,2,5,4,1.2,0,true,false,false,false,true,true},
        {6,1,5,6,9,1.2,0,false,false,false,true,true,true},
        {7,1,2,8,12,1.2,0,false,false,false,true,true,true},
        {8,1,2,9,3,1.2,0,false,true,false,true,true,true},
        {9,1,9,6,11,1.2,0,false,true,false,true,true,true}
    };
    for(int i=0;i<9;++i) nav.addConnection(e[i]);

    // Two-way connections must be entered in both directions.
    Connection reverse={10,1,2,1,10,1.5,0,false,false,false,true,true,true};
    nav.addConnection(reverse);

    nav.displayBuildings();
    nav.displayBuildingBlueprint(1);

    cout<<"\n===== WHEELCHAIR ROUTE =====\n";
    NavigationRoute r=nav.findAccessibleRoute(1,1,7,WHEELCHAIR);
    cout<<r.message<<"\n";
    if(r.found) {
        cout<<"Route: ";
        for(int i=0;i<r.locationCount;++i) {
            cout<<r.locationIds[i];
            if(i+1<r.locationCount)cout<<" -> ";
        }
        cout<<"\nDistance: "<<r.totalDistance<<" m\n";
    }
    if(!r.warnings.empty()) cout<<"Warnings: "<<r.warnings<<"\n";

    cout<<"\n===== BFS REACHABILITY =====\n";
    nav.displayReachableLocationsBFS(1,1,WHEELCHAIR);

    cout<<"\n===== ALTERNATIVE ROUTE =====\n";
    AlternativeRoutes options=nav.findAlternativeRoutes(1,1,7,WHEELCHAIR);
    if(options.alternativeFound) {
        cout<<"Alternative: ";
        for(int i=0;i<options.alternative.locationCount;++i) {
            cout<<options.alternative.locationIds[i];
            if(i+1<options.alternative.locationCount)cout<<" -> ";
        }
        cout<<"\nDistance: "<<options.alternative.totalDistance<<" m\n";
    } else cout<<"No alternative accessible route exists.\n";

    // Demonstrate path closure and recalculation.
    nav.setConnectionAvailability(1,7,false);
    cout<<"\nAfter marking connection 2 -> 8 unavailable:\n";
    NavigationRoute updated=nav.findAccessibleRoute(1,1,7,GENERAL);
    cout<<updated.message<<"\n";

    nav.saveBuildings("data/buildings.txt");
    nav.saveLocations("data/locations.txt");
    nav.saveConnections("data/connections.txt");
    return 0;
}
