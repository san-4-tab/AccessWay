#ifndef ACCESSPULSE_NAVIGATION_H
#define ACCESSPULSE_NAVIGATION_H

#include "../common/AccessPulseData.h"
#include <string>

const int AP1_MAX_ROUTE_LOCATIONS = 300;

struct NavigationRoute {
    bool found;
    int buildingId;
    int locationIds[AP1_MAX_ROUTE_LOCATIONS];
    int locationCount;
    float totalDistance;
    std::string message;
    std::string warnings;
};

struct AlternativeRoutes {
    NavigationRoute primary;
    NavigationRoute alternative;
    bool alternativeFound;
};

class NavigationSystem {
private:
    struct BuildingNode {
        Building data;
        BuildingNode* next;
    };

    struct LocationNode {
        Location data;
        LocationNode* next;
    };

    struct ConnectionNode {
        Connection data;
        ConnectionNode* next;
    };

    struct AdjNode {
        int connectionIndex;
        AdjNode* next;
    };

    struct HeapItem {
        int locationId;
        float distance;
    };

    struct MinHeap {
        HeapItem* items;
        int size;
        int capacity;
    };

    BuildingNode* buildingHead;
    LocationNode* locationHead;
    ConnectionNode* connectionHead;
    int buildingCount;
    int locationCount;
    int connectionCount;

    int hashLocation(int buildingId, int locationId) const;
    bool buildingExists(int buildingId) const;
    LocationNode* findLocation(int buildingId, int locationId) const;
    int countLocations(int buildingId) const;
    int countConnections(int buildingId) const;
    void heapPush(MinHeap& heap, int locationId, float distance) const;
    HeapItem heapPop(MinHeap& heap) const;

    bool connectionAllowed(const Connection& edge, MobilityProfile profile,
                           std::string& warning) const;
    NavigationRoute shortestRoute(int buildingId, int startId, int endId,
                                  MobilityProfile profile,
                                  int bannedConnectionId) const;
    void appendWarning(std::string& warnings, const std::string& warning) const;
    void clear();

public:
    NavigationSystem();
    ~NavigationSystem();

    NavigationSystem(const NavigationSystem&) = delete;
    NavigationSystem& operator=(const NavigationSystem&) = delete;

    // Building blueprint management
    bool addBuilding(const Building& building);
    bool addLocation(const Location& location);
    bool addConnection(const Connection& connection);
    bool setConnectionAvailability(int buildingId, int connectionId, bool available);
    bool removeConnection(int buildingId, int connectionId);

    // Navigation
    NavigationRoute findAccessibleRoute(int buildingId, int startLocationId,
                                         int destinationLocationId,
                                         MobilityProfile profile) const;
    AlternativeRoutes findAlternativeRoutes(int buildingId, int startLocationId,
                                              int destinationLocationId,
                                              MobilityProfile profile) const;
    void displayReachableLocationsBFS(int buildingId, int startLocationId,
                                      MobilityProfile profile) const;

    // Display and persistence
    int exportLocations(int buildingId, Location* output, int capacity) const;
    int exportConnections(int buildingId, Connection* output, int capacity) const;
    void displayBuildings() const;
    void displayBuildingBlueprint(int buildingId) const;
    bool saveBuildings(const std::string& filename) const;
    bool saveLocations(const std::string& filename) const;
    bool saveConnections(const std::string& filename) const;
    bool loadBuildings(const std::string& filename);
    bool loadLocations(const std::string& filename);
    bool loadConnections(const std::string& filename);
};

const char* mobilityProfileName(MobilityProfile profile);

#endif
